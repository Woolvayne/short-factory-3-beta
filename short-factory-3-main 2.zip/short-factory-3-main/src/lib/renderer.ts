/**
 * Local renderer — composites background clip + neural voice + quiet music
 * + word-synced captions onto a 9:16 canvas and captures it with
 * MediaRecorder. No server, no ffmpeg, no cloud. Safari-first (prefers MP4).
 */

import { buildCues, cueAt, type Cue, type WordTs } from "./tts";
import type { Settings } from "./settings";
import { resolveBitrate } from "./settings";
import { drawRedditIntro, type IntroOptions } from "./intro";

export interface RenderJobOptions {
  /** object URL of the background source (file blob or fetched remote blob) */
  bgUrl: string;
  /** where inside the source this clip begins, in seconds */
  clipStart: number;
  voiceMp3: ArrayBuffer;
  words: WordTs[];
  musicFile?: File | null;
  width: number;
  height: number;
  audioCtx: AudioContext;
  settings: Settings;
  /** Reddit-Story-Intro für die ersten Sekunden — null/undefined = aus */
  intro?: IntroOptions | null;
  onProgress?: (ratio: number) => void;
  signal?: { cancelled: boolean };
}

export interface LocalRenderResult {
  blob: Blob;
  mimeType: string;
  duration: number;
}

const MIME_CANDIDATES = [
  'video/mp4;codecs="avc1.42E028,mp4a.40.2"',
  'video/mp4;codecs="avc1.42E01E,mp4a.40.2"',
  "video/mp4;codecs=avc1,mp4a",
  "video/mp4",
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8,opus",
  "video/webm",
];

export function pickMimeType(): string {
  if (typeof MediaRecorder === "undefined") return "";
  return MIME_CANDIDATES.find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
}

export const recorderSupported = () => pickMimeType() !== "";

/** Wird auch von der Live-Vorschau (Settings → INTRO) benutzt. */
export function drawCaption(
  ctx: CanvasRenderingContext2D,
  text: string,
  w: number,
  h: number,
  s: Settings
): void {
  const fs = Math.round(w * s.captionScale);
  ctx.font = `900 ${fs}px "Arial Black", Arial, Helvetica, sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  const maxW = w * 0.85;
  const words = (s.uppercase ? text.toUpperCase() : text).split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const word of words) {
    const test = cur ? `${cur} ${word}` : word;
    if (cur && ctx.measureText(test).width > maxW) {
      lines.push(cur);
      cur = word;
    } else {
      cur = test;
    }
  }
  if (cur) lines.push(cur);

  const lineH = fs * 1.18;
  const centerY = h * s.captionY;
  const total = (lines.length - 1) * lineH;

  ctx.lineJoin = "round";
  ctx.miterLimit = 2;

  if (s.captionShadow) {
    ctx.shadowColor = "rgba(0,0,0,0.55)";
    ctx.shadowBlur = fs * 0.4;
    ctx.shadowOffsetY = Math.round(fs * 0.07);
  }

  const stroke = Math.round(fs * s.outlineWidth);
  lines.forEach((ln, i) => {
    const y = centerY - total / 2 + i * lineH;
    if (stroke > 0) {
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = stroke;
      ctx.strokeText(ln, w / 2, y);
    }
    ctx.fillStyle = s.captionColor;
    ctx.fillText(ln, w / 2, y);
  });

  ctx.shadowColor = "transparent";
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;
}

function drawCover(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  w: number,
  h: number,
  zoom: number,
  vignette: boolean
): void {
  const vw = video.videoWidth || 1;
  const vh = video.videoHeight || 1;
  const scale = Math.max(w / vw, h / vh) * zoom;
  const dw = vw * scale;
  const dh = vh * scale;
  ctx.drawImage(video, (w - dw) / 2, (h - dh) / 2, dw, dh);

  if (vignette) {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "rgba(0,0,0,0.30)");
    g.addColorStop(0.18, "rgba(0,0,0,0)");
    g.addColorStop(0.76, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.38)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
}

export async function renderLocal(opts: RenderJobOptions): Promise<LocalRenderResult> {
  const { width: w, height: h, audioCtx: ac, settings: s, intro } = opts;

  const mimeType = pickMimeType();
  if (!mimeType) {
    throw new Error(
      "MediaRecorder is unavailable — use iOS/iPadOS 17+, or a current Chrome/Edge/Firefox."
    );
  }

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("Canvas 2D is unavailable");

  /* ---- background element (hidden but attached — iOS needs it in the DOM) */
  const video = document.createElement("video");
  video.src = opts.bgUrl;
  video.muted = true;
  video.loop = false;
  video.playsInline = true;
  video.preload = "auto";
  video.crossOrigin = "anonymous";
  video.setAttribute("playsinline", "");
  video.setAttribute("webkit-playsinline", "");
  video.style.cssText =
    "position:fixed;left:-9999px;top:0;width:4px;height:4px;opacity:0;pointer-events:none";
  document.body.appendChild(video);

  const cleanup = () => {
    try {
      video.pause();
    } catch { /* noop */ }
    video.removeAttribute("src");
    try {
      video.load();
    } catch { /* noop */ }
    video.remove();
  };

  try {
    await new Promise<void>((res, rej) => {
      const t = window.setTimeout(() => rej(new Error("background clip failed to load")), 20000);
      video.oncanplay = () => {
        window.clearTimeout(t);
        res();
      };
      video.onerror = () => {
        window.clearTimeout(t);
        rej(new Error("background clip failed to decode"));
      };
      video.load();
    });

    /* ---- audio graph */
    if (ac.state !== "running") {
      try {
        await ac.resume();
      } catch { /* best effort */ }
    }
    const voiceBuf = await ac.decodeAudioData(opts.voiceMp3.slice(0));
    let musicBuf: AudioBuffer | null = null;
    if (opts.musicFile && s.musicVolume > 0) {
      try {
        musicBuf = await ac.decodeAudioData(await opts.musicFile.arrayBuffer());
      } catch {
        musicBuf = null; /* unreadable soundtrack — render voice only */
      }
    }

    const duration = Math.max(voiceBuf.duration + Math.max(0, s.tailPadding), 3);
    const cues: Cue[] = s.captionsOn
      ? buildCues(opts.words, voiceBuf.duration + 0.4, s.wordsPerCue)
      : [];

    const dest = ac.createMediaStreamDestination();

    const voiceSrc = ac.createBufferSource();
    voiceSrc.buffer = voiceBuf;
    const voiceGain = ac.createGain();
    voiceGain.gain.value = s.voiceVolume;
    voiceSrc.connect(voiceGain).connect(dest);

    let musicSrc: AudioBufferSourceNode | null = null;
    let musicGain: GainNode | null = null;
    if (musicBuf) {
      musicSrc = ac.createBufferSource();
      musicSrc.buffer = musicBuf;
      musicSrc.loop = true;
      musicGain = ac.createGain();
      musicGain.gain.value = s.musicVolume;
      musicSrc.connect(musicGain).connect(dest);
    }

    /* ---- recorder */
    const fps = Math.max(24, Math.min(60, s.fps));
    const canvasStream = canvas.captureStream(fps);
    const mixed = new MediaStream([
      ...canvasStream.getVideoTracks(),
      ...dest.stream.getAudioTracks(),
    ]);
    const recorder = new MediaRecorder(mixed, {
      mimeType,
      videoBitsPerSecond: resolveBitrate(s.bitrate, w),
      audioBitsPerSecond: 128_000,
    });
    const chunks: Blob[] = [];
    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) chunks.push(e.data);
    };
    const stopped = new Promise<void>((res) => {
      recorder.onstop = () => res();
    });

    /* ---- clip window inside the source */
    const srcDuration = isFinite(video.duration) && video.duration > 0 ? video.duration : duration;
    const segStart = Math.max(0, Math.min(opts.clipStart, Math.max(0, srcDuration - 0.4)));
    const segEnd = srcDuration;

    await new Promise<void>((res) => {
      const done = () => {
        video.removeEventListener("seeked", done);
        res();
      };
      video.addEventListener("seeked", done);
      video.currentTime = segStart;
      window.setTimeout(done, 3000);
    });

    /* ---- run */
    const startAt = ac.currentTime + 0.25;
    const endAt = startAt + duration;

    const drawFrame = () => {
      const t = Math.max(0, ac.currentTime - startAt);
      const zoom = s.zoomEffect ? 1 + 0.06 * Math.min(1, t / Math.max(1, duration)) : 1;
      if (video.readyState >= 2) drawCover(ctx, video, w, h, zoom, s.vignette);
      else {
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, w, h);
      }
      if (s.captionsOn) {
        const cue = cueAt(cues, t);
        if (cue) drawCaption(ctx, cue.text, w, h, s);
      }
      /* Titel-Card fliegt über die ersten `introDuration` Sekunden ein */
      if (intro && t <= intro.duration + 0.05) drawRedditIntro(ctx, w, h, t, intro);
    };

    let raf = 0;
    const loop = () => {
      /* keep the playhead inside the clip window */
      if (video.currentTime >= segEnd - 0.06 || video.ended) {
        try {
          video.currentTime = segStart;
          void video.play();
        } catch { /* noop */ }
      }
      drawFrame();
      if (ac.currentTime < endAt + 0.1) raf = requestAnimationFrame(loop);
    };

    try {
      await video.play();
    } catch {
      /* muted + playsinline should be allowed; continue regardless */
    }

    voiceSrc.start(startAt);
    if (musicSrc && musicGain) {
      musicSrc.start(startAt);
      if (s.musicFade) {
        musicGain.gain.setValueAtTime(s.musicVolume, Math.max(startAt, endAt - 1.4));
        musicGain.gain.linearRampToValueAtTime(0.0001, endAt);
      }
    }
    recorder.start(250);
    raf = requestAnimationFrame(loop);

    const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
    while (ac.currentTime < endAt) {
      if (opts.signal?.cancelled) break;
      opts.onProgress?.(Math.min(1, (ac.currentTime - startAt) / duration));
      await sleep(120);
    }

    cancelAnimationFrame(raf);
    drawFrame();
    recorder.stop();
    await stopped;
    opts.onProgress?.(1);

    try {
      voiceSrc.stop();
    } catch { /* already ended */ }
    try {
      musicSrc?.stop();
    } catch { /* noop */ }

    const blob = new Blob(chunks, { type: mimeType.split(";")[0] || "video/mp4" });
    if (blob.size === 0) throw new Error("recorder produced an empty file");
    return { blob, mimeType: blob.type || mimeType, duration };
  } finally {
    cleanup();
  }
}
